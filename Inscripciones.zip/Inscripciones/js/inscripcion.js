

function obtener() {
    alert("HOLA");
    
}