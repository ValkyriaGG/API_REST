
// -------------     FUNCIONES G E T ---------------
// Funcion que enlista a todos por alumnos
function todos() {

   const url = 'http://localhost/api.escuela.com/v1/alumnos/';

   fetch(url, {
      headers: {
         'Accept': 'application/json'
      }
   })
      .then(response => response.text())
      .then(text => document.getElementById("tabla").innerHTML = text)

}

// Funcion que enlista a un alumno por su id
function idAlumno() {
   const a = document.getElementById('idAlumno').value;
   const url = 'http://localhost/api.escuela.com/v1/alumnos/' + a;
   fetch(url, {
      headers: {
         'Accept': 'application/json'
      }
   })
      .then(response => response.text())
      .then(text => document.getElementById("tabla").innerHTML = text);
}

// Funcion que enlista a los alumnos por rango
function rango() {
   const a = document.getElementById('rango1').value;
   const b = document.getElementById('rango2').value;

   const url = 'http://localhost/api.escuela.com/v1/alumnos/' + a + "/" + b;

   fetch(url, {
      headers: {
         'Accept': 'application/json'
      }
   })
      .then((response) => response.text())
      .then(text => document.getElementById("tabla").innerHTML = text)
}

// Funcion que enlista a un alumno por su correo
function correo() {
   const correo = document.getElementById('correo').value;
   const url = 'http://localhost/api.escuela.com/v1/alumnos/usuarioPorCorreo/' + correo;

   fetch(url, {
      headers: {
         'Accept': 'application/json'
      }
   })
      .then((response) => response.text())
      .then(text => document.getElementById("tabla").innerHTML = text)
}

// -------------     F U N C I O N  P O S T ---------------

function registrar() {

   // Variables 
   const nombre = document.getElementById("nombre").value;
   const apePat = document.getElementById("apepaterno").value;
   const apeMat = document.getElementById("apematerno").value;
   const correo = document.getElementById("correo2").value;
   const direccion = document.getElementById("direccion").value;
   const fecha = document.getElementById("fecha").value;

   let _datos = {
      nombreAlumno: nombre,
      apellidoPat: apePat,
      apellidoMat: apeMat,
      email: correo,
      direccion: direccion,
      fechaNacimiento: fecha
   }

   fetch('http://localhost/api.escuela.com/v1/alumnos/registro', {
      method: "POST",
      body: JSON.stringify(_datos),
      headers: { "Content-type": "application/json" },
      mode: "no-cors"
   })
      .then(response => response.text())
      .then(text => document.getElementById("tabla2").innerHTML =  'REGISTRO HECHO, VERIFICA NUEVAMENTE LA LISTA')
      .catch(err => console.log(err));  
}

// -------------     F U N C I O N  P U T ---------------

function modificar() {
  
}