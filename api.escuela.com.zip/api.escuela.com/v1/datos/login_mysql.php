<?php
/**
 * Provee las constantes para conectarse a la base de datos
 * Mysql.
 */
define("NOMBRE_HOST", "localhost");// Nombre del host
define("BASE_DE_DATOS", "escuela"); // Nombre de la base de modelos
define("USUARIO", "root"); // Nombre del usuario
define("CONTRASENA", ""); // Constraseña