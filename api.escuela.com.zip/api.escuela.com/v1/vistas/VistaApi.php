<?php
abstract class VistaApi{

    // Código de error
    public $estado;

    public abstract function imprimir($cuerpo);
}